/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package lab5_1;
import java.util.*;

/**
 *
 * @author McIntosh
 */
public class Zeller {
     int year,m,q;
     public String beb;
    public Zeller(int year, int month, int day){
        this.year = year;
        this.m = month;
        this.q = day;
    }

    public enum Day{
        SUNDAY("Sunday"),
        MONDAY("Monday"),
        TUESDAY("Tuesday"),
        WEDNESDAY("Wednesday"),
        THURSDAY("Thursday"),
        FRIDAY("Friday"),
        SATURDAY("Saturday");
        
        private final String day,day1;
        Day(String day){
            this.day = day;
            this.day1 = day;
        }
        public String getDOW(){
        return day1;
    }
    }

    public Day getDayOfWeek(){
        
    
        if (m == 1){
            m=13;
            year--; 
        }
        if (m == 2) {
            m=14;
            year--; 
        }
        int k = year % 100; 
        int j = year / 100; 
        int h = (q + 13*(m + 1) / 5 + k + k / 4 + j / 4 + 5 * j)%7; 
        Day days = null;
        switch (h) 
        {
            case 0 : days = Day.SATURDAY; break; 
            case 1 : days = Day.SUNDAY; break;
            case 2 : days = Day.MONDAY; break; 
            case 3 : days = Day.TUESDAY; break; 
            case 4 : days = Day.WEDNESDAY; break; 
            case 5 : days = Day.THURSDAY; break; 
            case 6 : days = Day.FRIDAY; break; 
        }
        return days;
        
    }
}