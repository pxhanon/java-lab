package lab3_1;

public class InsectPopulation {
    
    private float Insect ;
    
    public InsectPopulation(float Insect){
        
        if(Insect>0){
            this.Insect = Insect;
        }else{
            throw new IllegalArgumentException("Error constructor<0");
        }
        
    }
    public void breed(){
        Insect = Insect*2;
        
    }
    public void spray(){
        Insect = ((Insect*90)/100) ;
    }
    public float getNumInsect(){
        return  Insect;
    }
}