/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_2;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author nutnichaboonrod
 */
public class Game {

    private int countPlayer = 0;
    private int countComp = 0;
    int num0 = 0;
                   int num1 = 1;
                   int num2 = 2;
      public Game(){
        
      }
   
      public void play(){
          while (countPlayer <= 2 || countComp <= 2)  {   
                System.out.println("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS");

                   if ((countPlayer - countComp) == 2 ){
                       System.out.println("Congrats! You win.");
                       System.out.println("User Score: " + countPlayer);
                       System.out.println("Computer Score: " + countComp);
                       break;
                   }
                   if ((countComp - countPlayer )== 2 ){
                       System.out.println("Too bad! You lose.");
                       System.out.println("User Score: " + countPlayer);
                       System.out.println("Computer Score: " + countComp);
                       break;
                   }
                   
                   Scanner input = new Scanner(System.in);
                   
                   String player1 = input.nextLine();
                   
                   
                   if (player1.equals(Integer.toString(num0)) || player1.equals(Integer.toString(num1)) || player1.equals(Integer.toString(num2))){
                   
                       int player = Integer.parseInt(player1);
                   player = player;
               
                
               
                   switch (player) {
                       case 0:
                           System.out.println("You enter: ROCK");
                           break;
                       case 1:
                           System.out.println("You enter: PAPER");
                           break;
                       case 2:
                           System.out.println("You enter: SCISSORS");
                           break;
                       default:
                           break;
                   }
                   
                   int comp;
                   String output;

                           Random random = new Random();
                           comp = random.nextInt(3) + 1;
                   switch (comp) {
                       case 1:
                           comp = 0; /* 0 = Rock */
                           break;
                       case 2:
                           comp= 1; /* 1 = Paper */
                           break;
                       case 3:
                           comp= 2; /* 2 = Scissors */
                           break;
                       default:
                           break;
                   }
                   if (comp == 0)
                       output = "ROCK";
                   else if (comp == 1)
                       output = "PAPER";
                   else 
                       output = "SCISSORS";

                           System.out.println("Computer: "+ output);
                

               switch(comp){
                   case 0:
                   if (player == 0){
                       System.out.println("It's a tie!");
                       break;
                   }
                   if (player == 1){
                               System.out.println("You win!");
                               countPlayer++;
                               break;
                               }
                   if (player == 2){
                       System.out.println("You lose!");
                       countComp++;
                       break;
                   }


                   case 1:
                       if (player == 0){
                       System.out.println("You lose!");
                       countComp++;
                       break;
                       }
                   if (player == 1){
                               System.out.println("It's a tie!");
                   break;
                               }
                   if (player == 2){
                       System.out.println("You win!");
                       countPlayer++;
                       break;
                   }
                   case 2:
                       if (player == 0){
                       System.out.println("You win!");
                       countPlayer++;
                       break;
                       }
                   if (player == 1){

                   System.out.println("You lose!");
                       countComp++;
                       break;
                               }
                   if (player == 2){
                       System.out.println("It's a tie!");
                       break;
                       
                   }
                 
               }
               
               
                   }
                
                

           }
          

       }

}
