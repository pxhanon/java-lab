
package lab7_2;

public class MagicSquare {
    String[][] board;
    public MagicSquare(int n){
        board = new String[n][n];
        int is = n-1;
        int js = n/2;
        for (int cnt = 1 ; cnt <= n*n;cnt++) {
            if(board[is][js]==null){
              board[is][js] = String.valueOf(cnt);
              is = is+1>=n ? 0 : is+1;
              js = js+1>=n ? 0 : js+1;
              if(board[is][js]!=null){
                is = is-1<0 ? n-1 : is-1;
              }
            }
        }
    }
    public String toString(){
        String finStr = "";
        for(String[] irow : board ){
            for(String j : irow){
              finStr+=j+"\t";
            }
            finStr+="\n";
        }

        return finStr;
    }
}
