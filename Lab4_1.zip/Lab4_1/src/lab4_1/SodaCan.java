/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_1;
/**
 *
 * @author usci
 */
public class SodaCan {
    private double h,d,v,sfa ;
    public SodaCan (double s2 ,double t ){
    h = s2 ;
    d = t;
    //double Volume =0 ;
    //double SFA = 0 ;
    }
    
    public double getVolume () {
        v = (Math.PI)*(d/2)*(d/2)*h    ; 
        return v ;
    }
    public double getSurfaceArea () {
        sfa = (2*(Math.PI)*(d/2)*h)+(2*((Math.PI)*(d/2)*(d/2))) ; 
        return sfa ;
    }
    
    
}
