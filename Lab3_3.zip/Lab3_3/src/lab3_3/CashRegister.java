package lab3_3;

public class CashRegister {
    
    private double fee,total,tax,money;
    
    public CashRegister (double fee){
        this.fee=fee;
    }
    
    public void recordPurchase(double amount){
        total+=amount;
    }
    
    public void recordTaxablePurchase(double amount){
        total+=amount*((100+fee)/100);
        tax+=amount*(fee/100);
    }
    
    public double getTotalTax(){
        return tax;
    }
    
    public void enterPayment(double amount){
        money+=amount;
    }
    
    public double giveChange(){
        double change=money-total;
        money=0;total=0;
        return change;
    }
}
