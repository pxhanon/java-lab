/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author prutprommart
 */
public class Pizza {

    private String name;
    private double price;

    public Pizza() {
    }
    public Pizza(String name, int price){
        this.name = name;
        this.price = price;
    }
    public double getPrice(){
        return this.price;
    }
    public String toString(){
        return name + " price : " + price;
    }
}
