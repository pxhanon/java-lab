
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author prutprommart
 */
public class Order {

    public static int cntOrder = 0;
    private int id;
    private Customer c;
    private ArrayList<Pizza> p = new ArrayList<Pizza>();

    public Order(Customer customer) {
        c = customer;
        id = ++cntOrder;

    }

    public void addPizza(Pizza p) {
        this.p.add(p);
    }

    public String getOrderDetail() {
        String text = "";
        double sum = 0;
        int cnt = 0;
        text = text + "Order id : " + id + "\n";
        text = text + c + "\n";
        for (Pizza n : p) {
            text = text + n + "\n";
            sum += n.getPrice();
            cnt++;
        }
        text += "Total pieces : " + cnt + "\n";
        text += "Total cost : " + sum;
        return text;
    }

    public double calculatePayment() {
        double sum = 0;
        for (Pizza n : p) {
            sum += n.getPrice();
        }
        sum -= sum * (c.getDiscount() / 100.0);
        return sum;
    }
}
