
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chanon
 */
public class Sequential {
    public static void main(String[] args) throws IOException, FileNotFoundException {
        File file = new File("/Users/chanon/NetBeansProjects/Lab12_1/src/text.txt");
        java.io.PrintWriter out = new PrintWriter(file);
        Scanner input = new Scanner(System.in);
        String line;
        do{
            line = (input.nextLine());
            out.print(!line.equals("quit") ? line + "\n" : "");
        }while(!line.equals("quit"));
        out.close();
        System.out.println("Total characters : " + file.length());
        System.out.println("Total words : " + words(file));
        System.out.println("Total lines : " + line(file));
    }
    
    public static int words(File file) throws IOException, FileNotFoundException{
        int cnt = 0;
        Scanner in = new Scanner(file);
        while (in.hasNextLine()){
            String line = in.nextLine();      
            cnt++;
            for (int i=0;i<line.length();i++){
                if (line.charAt(i)==' '){
                    cnt++;
                }
            }
        }
        in.close();
        return cnt;
    }
    
    public static int line(File file) throws IOException, FileNotFoundException{
        int l = 0;
        Scanner in = new Scanner(file);
        while (in.hasNextLine()){
            l++;
            in.nextLine();
        }
        in.close();
        return l;
    }
}
