
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author prutprommart
 */
public class MusicBox implements SimpleQueue {
    private ArrayList<String> music;
    public MusicBox(){
        music = new ArrayList<>();
        
    }
    public void enqueue(Object o){
        music.add((String) o);
        System.out.println(o + " is added in queue");
    }
    public void dequeue(){
        System.out.println("Now playing " + music.get(0));
        music.remove(0);
    }
}
