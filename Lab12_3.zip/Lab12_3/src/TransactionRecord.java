/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author prutprommart
 */
public class TransactionRecord {

    private int acctNo;
    private double amt;

    public TransactionRecord(int t, double a) {
        acctNo = t;
        amt = a;
    }

    public int getAccountNumber() {
        return acctNo;
    }

    public double getAmount() {
        return amt;
    }

}
