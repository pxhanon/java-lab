/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author prutprommart
 */
public class Sine extends Taylor {
    public Sine(int k, double x){
        super(k,x);
    }
    public void printValue(){
        System.out.println("Value from Math.cos() is " + Math.sin(getValue()) + "\nApproximated value is "
        + getApprox());
    }
    public double getApprox(){
        double total = 0;
        for (int i = 0; i <= getIter(); i++) {
            total = total + Math.pow(-1, i) * Math.pow(getValue(), 2*i + 1) / factorial(2*i + 1);
        }
        return total;
    }
}
